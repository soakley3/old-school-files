//
//  main.cpp
//  M6
//
//  Created by Lucas Oakley on 10/27/19.
//  Copyright © 2019 LucasOakley. All rights reserved.
//

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "Bridges.h"
#include "Color.h"
#include "ColorGrid.h"
#include "Bridges.h"
#include "KdTreeElement.h"

#include "Image.hpp"


using namespace bridges;
using namespace std;


KdTreeElement<int, int>  *insertKdTree (int *values, int count);

// res_x and res_y store the size of the image.
// This is found in the first two values of the .dat
int FILE_COUNT = 0;

//pixelsSize is later calculated to be res_x*res_y to store each value read from the file.
// later on, the program stores a new int[pixelsSize] in this to store all the values read
// from the file.
// stores file location

Image * images;



void readFile(string fil, int imageIndex) {
    ifstream reader;
    reader.open(fil);
    if (!reader) {
        cout << "Could not open the file.\n";
        exit(1);
    }
    
    std::string line;
    string word;
    string rezx, rezy;
    string tmp, scale;
    reader >> tmp; // first val from the file.
    reader >> rezx;
    reader >> rezy;
    reader >> scale;
    // convert the x and y values of the image into the global ints
    
    images[imageIndex] = Image();
    
    images[imageIndex].dimensionX = stoi(rezx);
    images[imageIndex].dimensionY = stoi(rezy);
    images[imageIndex].pixelSize = images[imageIndex].dimensionX*images[imageIndex].dimensionY*3;
    //allocate new memory for the int[] that stores all the values to be read in the file.
    images[imageIndex].pixels = new int[images[imageIndex].pixelSize];
    int i = 0;
    // we use largest int later on to help scale the values
    // read the file "word by word" so we dont have to manipulate the string with a delimeter.
    while (reader >> word) {
        // convert the "word" to an integer and store it in the appropriate place in the int[]
        // also record the largest value
        images[imageIndex].pixels[i] = stoi(word);
        i++;
    }
    cout << "This is " << rezx << " by " << rezy << " with the largest " << "\n";
    //return holding;
}

KdTreeElement<int, string> *buildImageTree (
    int *region,    // region - xmin, ymin, xmax, ymax
    int level,      // level of the tree, starts at 0 for root
    ColorGrid *cg,   // the region - originally the entire image
    bool dim_flag
);  // partitioning dimension, will flip with each
//  level



/*t0->setLeft(t1);
 t0->setRight(t2);
 t1->setLeft(t3);
 t1->setLabel("X");
 t1->setRight(t4);
 t2->setLeft(t5);
 t2->setRight(t6);*/

KdTreeElement<int, int> *insertKdTree (int *values, int count) {
    if (count < 1) {
        cout << "Invalid count to return the tree\n";
        return NULL;
    }
    int p = (count/2);
    int ticker = 0;
    KdTreeElement<int, int> *t[p];
    cout << "p " << p << "\n";
    t[0] = new KdTreeElement<int, int>(values[0], values[1]);
    ticker++;
    for (int j = 2; count > j; j++) {
        cout << "j1 = " << j << ", ticker = " << ticker << "\n";
        t[ticker] = new KdTreeElement<int, int>(values[j], values[(j+1)]);
        if (values[(j+1)] == 0)
            t[ticker]->setLabel("X");
        else
            t[ticker]->setLabel("Y");
        ticker++;
        j++;
    }
    cout << "ticker === " << ticker << "\n";
    int counter = 1;
    for (int j = 0; ticker > counter; j++) {
        cout << "j2 = " << j << " - "<< counter << "\n";
        t[j]->setLeft(t[counter]);
        counter++;
        t[j]->setRight(t[counter]);
        counter++;
    }
    

    return t[0];
}

/*
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}*/



void createGrid(int index) {
    images[index].cg = new ColorGrid(
            images[index].dimensionX,
            images[index].dimensionY,
            Color("white")
    );
    int ticker = 0;
    for (int j = 0; j < images[index].dimensionY;  j++) {
        for (int k = 0; k < images[index].dimensionX;  k++) {
            int tr, tg, tb;
            // get and store each r g b value from the large 1d array
            tr = images[index].pixels[ticker];
            ticker++;
            tg = images[index].pixels[ticker];
            ticker++;
            tb = images[index].pixels[ticker];
            images[index].cg->set(j, k, Color(tr, tg, tb));
            // store the colour value in a map for access during the greedy method.
            //map[j][k] = pixels[ticker];
            ticker++;
            //cout << "rgb - " << tr << ", " << tg << ", " << tb << "\n";
        }
    }
    
}
    

void createGrids() {
    for (int i = 0; FILE_COUNT > i; i++) {
        createGrid(i);
    }
}

void display2(Bridges* bridges, int index) {
    bridges->setDataStructure(images[index].cg);
    bridges->visualize();
}

// takes in the image and displays it using
// the color grid; pass in the Bridges object
// for visualization
void display (Bridges* bridges) {
    // initialize BRIDGES
    
    // set title for visualization
    bridges->setTitle("M6.2");
    
    //int res_x = getWidth(), res_y = getHeight();
    
    // create a blank grid so that we can fill it with grey space.
    ColorGrid *cg  = new ColorGrid(1000, 1000, Color("white"));
    
    // this will hold the colour value so that we can compare it for the greedy method.
    //int map[res_y][res_x];
    
    for (int i = 0; FILE_COUNT > i; i++) {
        int res_y = images[i].dimensionY;
        int res_x = images[i].dimensionX;
        
        int ticker = 0;
        for (int j = 0; j < res_y;  j++) {
            for (int k = 0; k < res_x;  k++) {
                int tr, tg, tb;
                // get and store each r g b value from the large 1d array
                tr = images[i].pixels[ticker];
                ticker++;
                tg = images[i].pixels[ticker];
                ticker++;
                tb = images[i].pixels[ticker];
                cg->set(j, k, Color(tr, tg, tb));
                // store the colour value in a map for access during the greedy method.
                //map[j][k] = pixels[ticker];
                ticker++;
                //cout << "rgb - " << tr << ", " << tg << ", " << tb << "\n";
            }
        }
    }
    //cout << "length - " << arrayLength << "\n";
    cout << "End display function.\n";
    // present the grid.
    bridges->setDataStructure(cg);
    
    bridges->visualize();
    
}



int main(int argc, char **argv) {
    // create bridges object
    //new Bridges(4, "walmartgardner", "1057152140079");
    FILE_COUNT = 1;
    /*string files[] = {"/Users/lucas/Projects/2019Fall/ITSC3112/M6/M6/face.ppm",
        "/Users/lucas/Projects/2019Fall/ITSC3112/M6/M6/mickey_mouse.ppm",
        "/Users/lucas/Projects/2019Fall/ITSC3112/M6/M6/square2.ppm"};*/
string files[] = {
    "/Users/lucas/Projects/2019Fall/ITSC3112/M6/M6/mickey_mouse.ppm"};
    
    images = new Image[FILE_COUNT];
    
    for (int i = 0; FILE_COUNT > i; i++) {
        readFile(files[i], i);
        images[i].printDemims();
    }
    
    
    
    Bridges bridges (6, "walmartgardner",
                     "1057152140079");
    /*bridges.setTitle("A Kd Tree Example");
    bridges.setDescription("A three-level tree with partitioners cycling between X and Y. The root node color is set to red while the leaf nodes that represent code letters are set to orange.");
    
    // create nodes
    KdTreeElement<int, int> *t0 = new KdTreeElement<int, int>(50, 0);
    KdTreeElement<int, int> *t1 = new KdTreeElement<int, int>(25, 1);
    KdTreeElement<int, int> *t2 = new KdTreeElement<int, int>(75, 1);
    KdTreeElement<int, int> *t3 = new KdTreeElement<int, int>(20, 0);
    KdTreeElement<int, int> *t4 = new KdTreeElement<int, int>(30, 0);
    KdTreeElement<int, int> *t5 = new KdTreeElement<int, int>(60, 0);
    KdTreeElement<int, int> *t6 = new KdTreeElement<int, int>(80, 0);
    //
    // form the links
    t0->setLeft(t1);
    t0->setRight(t2);
    t1->setLeft(t3);
    t1->setLabel("X");
    t1->setRight(t4);
    t2->setLeft(t5);
    t2->setRight(t6);
    
    // set partitioning dimension
    t0->setLabel("X");
    t1->setLabel("Y");
    t2->setLabel("Y");
    t3->setLabel("X");
    t4->setLabel("X");
    t5->setLabel("X");
    t6->setLabel("X");
    
    // set visual attributes
    t0->setColor("red");
    
    // color the leaf nodes that represent the code letters
    t1->setColor("orange");
    t4->setColor("orange");
    t5->setColor("orange");
    t6->setColor("orange");
    
    //int fillers[7][2]  = {{50, 0}, {25, 1}, {75, 1}, {20, 0}, {30, 0}, {60, 0}, {80, 0}};
    int fillers[14] = {50, 0, 25, 1, 75, 1, 20, 0, 30, 0, 60, 0, 80, 0};
    KdTreeElement<int, int> zz = *insertKdTree(fillers, 14);
    
    
    // provide BRIDGES the  handle to the tree structure and visualize
    bridges.setDataStructure(t0);
    bridges.visualize();
    bridges.setDataStructure(zz);
    
    bridges.visualize();*/
    //display(&bridges);
    display2(&bridges, 0);
    return 0;
}
